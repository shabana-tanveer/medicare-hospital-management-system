# MediCare - Hospital Management System (Full Stack MERN)

Enterprise-grade Full Stack Hospital Management System built with MongoDB, Express.js, React (Vite, Tailwind CSS), and Node.js.

## 🌟 Key Features
- **Multi-Role Access Control (RBAC):** Admin, Doctor, Patient, and Receptionist dashboards.
- **Appointment Lifecycle:** Real-time scheduling, confirmation, and status tracking.
- **Electronic Health Records (EHR):** Clinical history, diagnosis logs, and PDF digital prescriptions.
- **JWT Auth & Security:** Role-based route protection, bcrypt password hashing, and HTTP security headers.
- **RESTful API Architecture:** Standardized API responses, pagination, error handling middleware.

## 🚀 Quick Start Guide

### Prerequisites
- Node.js (v18+)
- MongoDB Atlas or local MongoDB instance

### Setup & Run
1. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/medicare-hospital-management-system.git
   cd medicare-hospital-management-system
   ```

2. **Install Server Dependencies:**
   ```bash
   cd server
   npm install
   ```

3. **Install Client Dependencies:**
   ```bash
   cd ../client
   npm install
   ```

4. **Environment Setup:**
   Copy `.env.example` to `server/.env` and fill in your MongoDB URI & JWT Secret.

5. **Run Development Server:**
   ```bash
   npm run dev
   ```