const router = require('express').Router();
const { getRecords, createRecord } = require('../controllers/recordController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.use(protect);
router.route('/')
  .get(authorize('admin', 'doctor', 'patient'), getRecords)
  .post(authorize('doctor'), createRecord);

module.exports = router;
