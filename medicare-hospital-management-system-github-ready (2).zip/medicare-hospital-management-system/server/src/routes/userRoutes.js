const router = require('express').Router();
const { getDoctors, getUsers, createUser, deleteUser } = require('../controllers/userController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.use(protect);
router.get('/doctors', getDoctors);
router.route('/')
  .get(authorize('admin', 'receptionist', 'doctor'), getUsers)
  .post(authorize('admin'), createUser);
router.delete('/:id', authorize('admin'), deleteUser);

module.exports = router;
