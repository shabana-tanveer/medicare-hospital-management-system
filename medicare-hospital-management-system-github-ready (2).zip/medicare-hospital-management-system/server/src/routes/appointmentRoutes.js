const router = require('express').Router();
const { getAppointments, createAppointment, updateAppointment } = require('../controllers/appointmentController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.use(protect);
router.route('/')
  .get(getAppointments)
  .post(authorize('patient', 'admin', 'receptionist'), createAppointment);
router.put('/:id', updateAppointment);

module.exports = router;
