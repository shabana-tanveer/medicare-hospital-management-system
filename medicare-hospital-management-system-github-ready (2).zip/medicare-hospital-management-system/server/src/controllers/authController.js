const jwt = require('jsonwebtoken');
const User = require('../models/User');
const httpError = require('../utils/httpError');

const publicUser = (u) => ({
  id: u._id, name: u.name, email: u.email, role: u.role, phone: u.phone, avatar: u.avatar
});

const sendToken = (user, status, res) => {
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '30d'
  });
  res.status(status).json({ success: true, token, user: publicUser(user) });
};

// @route POST /api/v1/auth/register  (public sign-up always creates a patient)
exports.register = async (req, res, next) => {
  try {
    const { name, email, password, phone, bloodGroup } = req.body;
    if (!password || String(password).length < 6) {
      throw httpError(400, 'Password must be at least 6 characters');
    }
    const user = await User.create({ name, email, password: String(password), phone, bloodGroup, role: 'patient' });
    sendToken(user, 201, res);
  } catch (err) {
    next(err);
  }
};

// @route POST /api/v1/auth/login
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) throw httpError(400, 'Please provide email and password');
    const user = await User.findOne({ email: String(email).toLowerCase() }).select('+password');
    if (!user || !(await user.matchPassword(String(password)))) {
      throw httpError(401, 'Invalid email or password');
    }
    sendToken(user, 200, res);
  } catch (err) {
    next(err);
  }
};

// @route GET /api/v1/auth/me
exports.getMe = (req, res) => {
  res.status(200).json({ success: true, user: publicUser(req.user) });
};
