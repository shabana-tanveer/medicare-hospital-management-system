const User = require('../models/User');
const httpError = require('../utils/httpError');

// @route GET /api/v1/users/doctors  (any logged-in user)
exports.getDoctors = async (req, res, next) => {
  try {
    const doctors = await User.find({ role: 'doctor' }).select('name specialization').sort('name');
    res.status(200).json({ success: true, count: doctors.length, data: doctors });
  } catch (err) {
    next(err);
  }
};

// @route GET /api/v1/users?role=patient  (admin, receptionist, doctor)
exports.getUsers = async (req, res, next) => {
  try {
    const query = {};
    if (req.query.role) query.role = String(req.query.role);
    // Doctors may only look up patients
    if (req.user.role === 'doctor') query.role = 'patient';
    const users = await User.find(query).select('-__v').sort('name');
    res.status(200).json({ success: true, count: users.length, data: users });
  } catch (err) {
    next(err);
  }
};

// @route POST /api/v1/users  (admin only - create staff or patients)
exports.createUser = async (req, res, next) => {
  try {
    const { name, email, password, role, phone, specialization, bloodGroup } = req.body;
    if (!password || String(password).length < 6) {
      throw httpError(400, 'Password must be at least 6 characters');
    }
    const user = await User.create({
      name, email, password: String(password), role, phone, specialization, bloodGroup
    });
    const safe = user.toObject();
    delete safe.password;
    res.status(201).json({ success: true, data: safe });
  } catch (err) {
    next(err);
  }
};

// @route DELETE /api/v1/users/:id  (admin only)
exports.deleteUser = async (req, res, next) => {
  try {
    if (req.params.id === req.user.id) throw httpError(400, 'You cannot delete your own account');
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) throw httpError(404, 'User not found');
    res.status(200).json({ success: true, data: {} });
  } catch (err) {
    next(err);
  }
};
