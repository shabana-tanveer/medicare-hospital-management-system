const Appointment = require('../models/Appointment');
const User = require('../models/User');
const httpError = require('../utils/httpError');

// @desc Get appointments (patients/doctors only see their own)
// @route GET /api/v1/appointments
exports.getAppointments = async (req, res, next) => {
  try {
    const query = {};
    if (req.user.role === 'patient') query.patient = req.user.id;
    if (req.user.role === 'doctor') query.doctor = req.user.id;

    const appointments = await Appointment.find(query)
      .populate('patient', 'name email phone bloodGroup')
      .populate('doctor', 'name specialization')
      .sort({ date: 1, time: 1 });

    res.status(200).json({ success: true, count: appointments.length, data: appointments });
  } catch (err) {
    next(err);
  }
};

// @desc Create appointment
// @route POST /api/v1/appointments
exports.createAppointment = async (req, res, next) => {
  try {
    const { doctor, date, time, type, notes } = req.body;
    const patient = req.user.role === 'patient' ? req.user.id : req.body.patient;
    if (!patient || !doctor) throw httpError(400, 'Patient and doctor are required');

    const [p, d] = await Promise.all([
      User.findOne({ _id: patient, role: 'patient' }),
      User.findOne({ _id: doctor, role: 'doctor' })
    ]);
    if (!p) throw httpError(404, 'Patient not found');
    if (!d) throw httpError(404, 'Doctor not found');

    const appointment = await Appointment.create({ patient, doctor, date, time, type, notes });
    res.status(201).json({ success: true, data: appointment });
  } catch (err) {
    next(err);
  }
};

const ALLOWED_STATUS = {
  patient: ['Cancelled'],
  receptionist: ['Confirmed', 'Cancelled'],
  doctor: ['Confirmed', 'Completed', 'Cancelled'],
  admin: ['Pending', 'Confirmed', 'Completed', 'Cancelled']
};

// @desc Update status / notes
// @route PUT /api/v1/appointments/:id
exports.updateAppointment = async (req, res, next) => {
  try {
    const appointment = await Appointment.findById(req.params.id);
    if (!appointment) throw httpError(404, 'Appointment not found');

    const { role, id } = req.user;
    if (role === 'patient' && String(appointment.patient) !== id) throw httpError(403, 'Not your appointment');
    if (role === 'doctor' && String(appointment.doctor) !== id) throw httpError(403, 'Not your appointment');
    if (role !== 'admin' && ['Completed', 'Cancelled'].includes(appointment.status)) {
      throw httpError(400, `This appointment is already ${appointment.status.toLowerCase()}`);
    }

    const { status, notes } = req.body;
    if (status) {
      if (!ALLOWED_STATUS[role].includes(status)) {
        throw httpError(403, `${role} cannot set status to ${status}`);
      }
      appointment.status = status;
    }
    if (notes !== undefined && role !== 'patient') appointment.notes = notes;

    await appointment.save();
    res.status(200).json({ success: true, data: appointment });
  } catch (err) {
    next(err);
  }
};
