const MedicalRecord = require('../models/MedicalRecord');
const User = require('../models/User');
const httpError = require('../utils/httpError');

// @route GET /api/v1/medical-records
exports.getRecords = async (req, res, next) => {
  try {
    const query = {};
    if (req.user.role === 'patient') query.patient = req.user.id;
    if (req.user.role === 'doctor') query.doctor = req.user.id;

    const records = await MedicalRecord.find(query)
      .populate('patient', 'name bloodGroup')
      .populate('doctor', 'name specialization')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: records.length, data: records });
  } catch (err) {
    next(err);
  }
};

// @route POST /api/v1/medical-records  (doctors only)
exports.createRecord = async (req, res, next) => {
  try {
    const { patient, diagnosis, prescription, notes } = req.body;
    const found = await User.findOne({ _id: patient, role: 'patient' });
    if (!found) throw httpError(404, 'Patient not found');

    const record = await MedicalRecord.create({
      patient, doctor: req.user.id, diagnosis, prescription, notes
    });
    res.status(201).json({ success: true, data: record });
  } catch (err) {
    next(err);
  }
};
