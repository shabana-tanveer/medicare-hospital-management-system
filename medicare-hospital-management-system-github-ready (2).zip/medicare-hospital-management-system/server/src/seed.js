// Creates demo accounts so you can log in right away:  npm run seed
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');

const password = process.env.SEED_PASSWORD || 'Password123!';

const demoUsers = [
  { name: 'Admin User', email: 'admin@medicare.local', role: 'admin' },
  { name: 'Riya Reception', email: 'reception@medicare.local', role: 'receptionist' },
  { name: 'Dr. Ayesha Khan', email: 'doctor@medicare.local', role: 'doctor', specialization: 'Cardiology' },
  { name: 'Dr. Bilal Ahmed', email: 'doctor2@medicare.local', role: 'doctor', specialization: 'Pediatrics' },
  { name: 'Sana Patient', email: 'patient@medicare.local', role: 'patient', bloodGroup: 'B+' }
];

(async () => {
  await connectDB();
  for (const u of demoUsers) {
    if (await User.findOne({ email: u.email })) {
      console.log(`Skipped (exists): ${u.email}`);
      continue;
    }
    await User.create({ ...u, password });
    console.log(`Created ${u.role}: ${u.email}`);
  }
  console.log(`\nDemo password for all accounts: ${password}`);
  await mongoose.disconnect();
})();
