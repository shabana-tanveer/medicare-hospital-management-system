# MediCare - Hospital Management System

A full-stack MERN hospital management app: MongoDB, Express, React (Vite + Tailwind CSS) and Node.js.

## Features
- **Role-based access control:** admin, doctor, patient and receptionist, enforced on both the API and the UI.
- **Appointments:** patients and front-desk staff book; staff confirm, doctors complete, anyone involved can cancel (each role only gets the actions it is allowed).
- **Medical records:** doctors write diagnoses and prescriptions; patients see only their own records.
- **People management:** admins add and remove doctors, staff and patients.
- **Security basics:** JWT authentication, bcrypt password hashing, Helmet security headers, public sign-up limited to the patient role.

## Tech stack
| Layer | Tools |
| --- | --- |
| Frontend | React 18, React Router 6, Vite, Tailwind CSS |
| Backend | Node.js, Express, Mongoose, JSON Web Tokens |
| Database | MongoDB (Atlas or local) |

## Getting started

### Prerequisites
- Node.js 18 or newer
- A MongoDB Atlas cluster or a local MongoDB instance

### Setup
1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/medicare-hospital-management-system.git
   cd medicare-hospital-management-system
   ```

2. **Install all dependencies**
   ```bash
   npm run install-all
   ```

3. **Configure environment variables**
   Copy `.env.example` to `.env` in the project root, then set `MONGODB_URI` and a long random `JWT_SECRET`.

4. **(Optional) Create demo accounts**
   ```bash
   npm run seed
   ```
   This creates one account per role (`admin@medicare.local`, `doctor@medicare.local`, `reception@medicare.local`, `patient@medicare.local`) with the password `Password123!`, or the value of `SEED_PASSWORD` if you set it. Use the seed for local development only.

5. **Start the app**
   ```bash
   npm run dev
   ```
   API: http://localhost:5000, web app: http://localhost:5173

## API overview
All routes are under `/api/v1` and, except sign-up and login, need an `Authorization: Bearer <token>` header.

| Method | Route | Who |
| --- | --- | --- |
| POST | `/auth/register`, `/auth/login` | Public |
| GET | `/auth/me` | Any signed-in user |
| GET | `/users/doctors` | Any signed-in user |
| GET | `/users?role=patient` | Admin, receptionist, doctor |
| POST, DELETE | `/users`, `/users/:id` | Admin |
| GET | `/appointments` | Any (patients and doctors see only their own) |
| POST | `/appointments` | Patient, receptionist, admin |
| PUT | `/appointments/:id` | Any involved role, limited by role |
| GET | `/medical-records` | Admin, doctor, patient |
| POST | `/medical-records` | Doctor |

## Project structure
```
server/src   config, models, controllers, routes, middleware, seed script
client/src   pages, components, auth context, API helper
```

## Roadmap
- PDF prescriptions
- Pagination and search
- Automated tests
- Password reset
