/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['Figtree', 'system-ui', 'sans-serif'] },
      colors: {
        ink: '#12262B',
        paper: '#F4F6F3',
        line: '#DCE3DE',
        leaf: { DEFAULT: '#1F7A5C', dark: '#165C45' }
      }
    }
  },
  plugins: []
};
