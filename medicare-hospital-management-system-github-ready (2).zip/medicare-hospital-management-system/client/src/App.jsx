import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import DashboardLayout from './components/DashboardLayout';
import Login from './pages/Login';
import Overview from './pages/Overview';
import AppointmentList from './pages/AppointmentList';
import MedicalRecords from './pages/MedicalRecords';
import People from './pages/People';

function RequireAuth({ roles, children }) {
  const { user, loading } = useAuth();
  if (loading) return <p className="p-8 text-sm text-ink/60">Loading...</p>;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route element={<RequireAuth><DashboardLayout /></RequireAuth>}>
            <Route index element={<Overview />} />
            <Route path="appointments" element={<AppointmentList />} />
            <Route path="records" element={<RequireAuth roles={['admin', 'doctor', 'patient']}><MedicalRecords /></RequireAuth>} />
            <Route path="people" element={<RequireAuth roles={['admin']}><People /></RequireAuth>} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
