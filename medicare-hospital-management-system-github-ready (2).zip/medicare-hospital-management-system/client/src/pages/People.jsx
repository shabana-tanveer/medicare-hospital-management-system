import { useCallback, useEffect, useState } from 'react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import { Button, ErrorNote, Field, PageHeader, inputCls } from '../components/ui';

const ROLES = ['doctor', 'receptionist', 'patient', 'admin'];
const blank = { name: '', email: '', password: '', role: 'doctor', specialization: '' };

export default function People() {
  const { user } = useAuth();
  const [people, setPeople] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(blank);
  const [error, setError] = useState('');

  const load = useCallback(() => {
    api('/users').then((d) => setPeople(d.data)).catch((e) => setError(e.message));
  }, []);
  useEffect(load, [load]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const create = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api('/users', { method: 'POST', body: form });
      setForm(blank);
      setShowForm(false);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const remove = async (p) => {
    if (!window.confirm(`Delete ${p.name}? This cannot be undone.`)) return;
    setError('');
    try {
      await api(`/users/${p._id}`, { method: 'DELETE' });
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <>
      <PageHeader
        title="People"
        subtitle="Doctors, staff and patients with access to the system."
        action={<Button onClick={() => setShowForm(!showForm)}>{showForm ? 'Close form' : 'Add person'}</Button>}
      />
      <ErrorNote message={error} />

      {showForm && (
        <form onSubmit={create} className="mb-8 grid gap-4 rounded-lg border border-line bg-white p-5 md:grid-cols-2">
          <Field label="Full name"><input className={inputCls} value={form.name} onChange={set('name')} required /></Field>
          <Field label="Email"><input type="email" className={inputCls} value={form.email} onChange={set('email')} required /></Field>
          <Field label="Temporary password"><input type="password" minLength={6} className={inputCls} value={form.password} onChange={set('password')} required /></Field>
          <Field label="Role">
            <select className={inputCls} value={form.role} onChange={set('role')}>
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
          </Field>
          {form.role === 'doctor' && (
            <Field label="Specialization"><input className={inputCls} value={form.specialization} onChange={set('specialization')} /></Field>
          )}
          <div className="md:col-span-2"><Button type="submit">Add person</Button></div>
        </form>
      )}

      <div className="overflow-x-auto rounded-lg border border-line bg-white">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line bg-paper text-ink/70">
            <tr>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Email</th>
              <th className="px-4 py-3 font-medium">Role</th>
              <th className="px-4 py-3 font-medium"><span className="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {people.map((p) => (
              <tr key={p._id}>
                <td className="px-4 py-3">{p.name}{p.specialization ? `, ${p.specialization}` : ''}</td>
                <td className="px-4 py-3">{p.email}</td>
                <td className="px-4 py-3">{p.role}</td>
                <td className="px-4 py-3 text-right">
                  {p._id !== user.id && (
                    <Button variant="danger" className="px-2 py-1 text-xs" onClick={() => remove(p)}>Delete</Button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
