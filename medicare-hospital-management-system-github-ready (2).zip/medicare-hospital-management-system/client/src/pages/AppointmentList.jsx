import { useCallback, useEffect, useState } from 'react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import { Button, Empty, ErrorNote, Field, PageHeader, StatusBadge, fmtDate, inputCls } from '../components/ui';

const TYPES = ['General consultation', 'Follow-up', 'Check-up', 'Lab review', 'Emergency'];
const today = () => new Date().toISOString().slice(0, 10);
const blank = { patient: '', doctor: '', date: '', time: '', type: TYPES[0], notes: '' };

export default function AppointmentList() {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(blank);
  const [error, setError] = useState('');

  const isPatient = user.role === 'patient';
  const canBook = ['patient', 'admin', 'receptionist'].includes(user.role);

  const load = useCallback(() => {
    api('/appointments').then((d) => setItems(d.data)).catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    load();
    if (canBook) {
      api('/users/doctors').then((d) => setDoctors(d.data)).catch(() => {});
      if (!isPatient) api('/users?role=patient').then((d) => setPatients(d.data)).catch(() => {});
    }
  }, [load, canBook, isPatient]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const book = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api('/appointments', { method: 'POST', body: form });
      setForm(blank);
      setShowForm(false);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const setStatus = async (id, status) => {
    setError('');
    try {
      await api(`/appointments/${id}`, { method: 'PUT', body: { status } });
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const actionsFor = (a) => {
    if (['Completed', 'Cancelled'].includes(a.status)) return [];
    const acts = [];
    if (a.status === 'Pending' && !isPatient) acts.push(['Confirm', 'Confirmed', 'ghost']);
    if (a.status === 'Confirmed' && ['doctor', 'admin'].includes(user.role)) acts.push(['Complete', 'Completed', 'ghost']);
    acts.push(['Cancel', 'Cancelled', 'danger']);
    return acts;
  };

  return (
    <>
      <PageHeader
        title="Appointments"
        subtitle={isPatient ? 'Your bookings with doctors.' : 'Schedule and track appointments.'}
        action={canBook && <Button onClick={() => setShowForm(!showForm)}>{showForm ? 'Close form' : 'Book appointment'}</Button>}
      />
      <ErrorNote message={error} />

      {showForm && (
        <form onSubmit={book} className="mb-8 grid gap-4 rounded-lg border border-line bg-white p-5 md:grid-cols-2">
          {!isPatient && (
            <Field label="Patient">
              <select className={inputCls} value={form.patient} onChange={set('patient')} required>
                <option value="">Select patient</option>
                {patients.map((p) => <option key={p._id} value={p._id}>{p.name}</option>)}
              </select>
            </Field>
          )}
          <Field label="Doctor">
            <select className={inputCls} value={form.doctor} onChange={set('doctor')} required>
              <option value="">Select doctor</option>
              {doctors.map((d) => (
                <option key={d._id} value={d._id}>{d.name}{d.specialization ? `, ${d.specialization}` : ''}</option>
              ))}
            </select>
          </Field>
          <Field label="Date">
            <input type="date" min={today()} className={inputCls} value={form.date} onChange={set('date')} required />
          </Field>
          <Field label="Time">
            <input type="time" className={inputCls} value={form.time} onChange={set('time')} required />
          </Field>
          <Field label="Type">
            <select className={inputCls} value={form.type} onChange={set('type')}>
              {TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Notes (optional)">
            <input className={inputCls} value={form.notes} onChange={set('notes')} />
          </Field>
          <div className="md:col-span-2">
            <Button type="submit">Book appointment</Button>
          </div>
        </form>
      )}

      {items.length === 0 ? (
        <Empty>No appointments yet.</Empty>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-line bg-white">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line bg-paper text-ink/70">
              <tr>
                <th className="px-4 py-3 font-medium">When</th>
                <th className="px-4 py-3 font-medium">Patient</th>
                <th className="px-4 py-3 font-medium">Doctor</th>
                <th className="px-4 py-3 font-medium">Type</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {items.map((a) => (
                <tr key={a._id}>
                  <td className="whitespace-nowrap px-4 py-3">{fmtDate(a.date)}, {a.time}</td>
                  <td className="px-4 py-3">{a.patient?.name || 'Removed user'}</td>
                  <td className="px-4 py-3">{a.doctor?.name || 'Removed user'}</td>
                  <td className="px-4 py-3">{a.type}</td>
                  <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      {actionsFor(a).map(([label, status, variant]) => (
                        <Button key={status} variant={variant} className="px-2 py-1 text-xs" onClick={() => setStatus(a._id, status)}>
                          {label}
                        </Button>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
