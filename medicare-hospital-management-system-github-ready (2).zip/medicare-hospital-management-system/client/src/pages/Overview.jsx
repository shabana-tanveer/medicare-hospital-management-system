import { useEffect, useState } from 'react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import { Empty, ErrorNote, PageHeader, StatusBadge, fmtDate } from '../components/ui';

const STATUSES = ['Pending', 'Confirmed', 'Completed', 'Cancelled'];

export default function Overview() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [people, setPeople] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api('/appointments').then((d) => setAppointments(d.data)).catch((e) => setError(e.message));
    if (user.role === 'admin') api('/users').then((d) => setPeople(d.data)).catch(() => {});
  }, [user.role]);

  const count = (s) => appointments.filter((a) => a.status === s).length;
  const upcoming = appointments.filter((a) => ['Pending', 'Confirmed'].includes(a.status)).slice(0, 6);
  const roleCount = (r) => people.filter((p) => p.role === r).length;

  return (
    <>
      <PageHeader title={`Welcome back, ${user.name}`} subtitle="Here is where appointments stand today." />
      <ErrorNote message={error} />

      <div className="grid grid-cols-2 divide-x divide-line overflow-hidden rounded-lg border border-line bg-white md:grid-cols-4">
        {STATUSES.map((s) => (
          <div key={s} className="px-5 py-4">
            <p className="text-3xl font-semibold">{count(s)}</p>
            <p className="mt-1 text-sm text-ink/60">{s}</p>
          </div>
        ))}
      </div>

      <h2 className="mb-3 mt-10 text-lg font-semibold">Upcoming appointments</h2>
      {upcoming.length === 0 ? (
        <Empty>No upcoming appointments. Book one from the Appointments page.</Empty>
      ) : (
        <ul className="divide-y divide-line rounded-lg border border-line bg-white">
          {upcoming.map((a) => (
            <li key={a._id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
              <div>
                <p className="font-medium">{a.patient?.name} with {a.doctor?.name}</p>
                <p className="text-ink/60">{fmtDate(a.date)} at {a.time}, {a.type}</p>
              </div>
              <StatusBadge status={a.status} />
            </li>
          ))}
        </ul>
      )}

      {user.role === 'admin' && (
        <>
          <h2 className="mb-3 mt-10 text-lg font-semibold">People</h2>
          <p className="text-sm text-ink/70">
            {roleCount('doctor')} doctors, {roleCount('patient')} patients, {roleCount('receptionist')} receptionists and {roleCount('admin')} admins are registered.
          </p>
        </>
      )}
    </>
  );
}
