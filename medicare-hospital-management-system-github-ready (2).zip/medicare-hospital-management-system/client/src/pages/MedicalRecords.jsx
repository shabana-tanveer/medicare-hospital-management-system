import { useCallback, useEffect, useState } from 'react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import { Button, Empty, ErrorNote, Field, PageHeader, inputCls } from '../components/ui';

const blank = { patient: '', diagnosis: '', prescription: '', notes: '' };

export default function MedicalRecords() {
  const { user } = useAuth();
  const [records, setRecords] = useState([]);
  const [patients, setPatients] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(blank);
  const [error, setError] = useState('');
  const isDoctor = user.role === 'doctor';

  const load = useCallback(() => {
    api('/medical-records').then((d) => setRecords(d.data)).catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    load();
    if (isDoctor) api('/users?role=patient').then((d) => setPatients(d.data)).catch(() => {});
  }, [load, isDoctor]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api('/medical-records', { method: 'POST', body: form });
      setForm(blank);
      setShowForm(false);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <>
      <PageHeader
        title="Medical records"
        subtitle={user.role === 'patient' ? 'Your diagnoses and prescriptions.' : 'Clinical history and prescriptions.'}
        action={isDoctor && <Button onClick={() => setShowForm(!showForm)}>{showForm ? 'Close form' : 'Add record'}</Button>}
      />
      <ErrorNote message={error} />

      {showForm && (
        <form onSubmit={save} className="mb-8 space-y-4 rounded-lg border border-line bg-white p-5">
          <Field label="Patient">
            <select className={inputCls} value={form.patient} onChange={set('patient')} required>
              <option value="">Select patient</option>
              {patients.map((p) => <option key={p._id} value={p._id}>{p.name}</option>)}
            </select>
          </Field>
          <Field label="Diagnosis">
            <input className={inputCls} value={form.diagnosis} onChange={set('diagnosis')} required />
          </Field>
          <Field label="Prescription">
            <textarea rows={3} className={inputCls} value={form.prescription} onChange={set('prescription')} />
          </Field>
          <Field label="Notes">
            <textarea rows={2} className={inputCls} value={form.notes} onChange={set('notes')} />
          </Field>
          <Button type="submit">Save record</Button>
        </form>
      )}

      {records.length === 0 ? (
        <Empty>No medical records yet.</Empty>
      ) : (
        <ul className="divide-y divide-line rounded-lg border border-line bg-white">
          {records.map((r) => (
            <li key={r._id} className="px-5 py-4 text-sm">
              <div className="flex flex-wrap justify-between gap-2">
                <p className="font-semibold">{r.diagnosis}</p>
                <p className="text-ink/60">{new Date(r.createdAt).toLocaleDateString()}</p>
              </div>
              <p className="mt-1 text-ink/70">
                {r.patient?.name}{r.patient?.bloodGroup ? ` (${r.patient.bloodGroup})` : ''}, seen by {r.doctor?.name}
              </p>
              {r.prescription && <p className="mt-2 whitespace-pre-line"><span className="font-medium">Prescription:</span> {r.prescription}</p>}
              {r.notes && <p className="mt-1 whitespace-pre-line text-ink/70">{r.notes}</p>}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
