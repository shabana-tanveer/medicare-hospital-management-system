import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button, ErrorNote, Field, inputCls } from '../components/ui';

export default function Login() {
  const { user, login, register } = useAuth();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (mode === 'login') await login(form.email, form.password);
      else await register(form);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen md:grid-cols-2">
      <div className="hidden flex-col justify-between bg-ink p-10 text-white md:flex">
        <span className="text-xl font-semibold tracking-tight">MediCare</span>
        <p className="max-w-sm text-3xl font-semibold leading-snug">
          Appointments, records and staff in one place.
        </p>
      </div>

      <div className="flex items-center justify-center p-6">
        <form onSubmit={submit} className="w-full max-w-sm space-y-4">
          <h1 className="text-2xl font-semibold">
            {mode === 'login' ? 'Sign in' : 'Create patient account'}
          </h1>
          <ErrorNote message={error} />
          {mode === 'register' && (
            <Field label="Full name">
              <input className={inputCls} value={form.name} onChange={set('name')} required />
            </Field>
          )}
          <Field label="Email">
            <input type="email" className={inputCls} value={form.email} onChange={set('email')} required />
          </Field>
          <Field label="Password">
            <input type="password" className={inputCls} value={form.password} onChange={set('password')} minLength={6} required />
          </Field>
          <Button type="submit" disabled={busy} className="w-full">
            {busy ? 'Please wait...' : mode === 'login' ? 'Sign in' : 'Create account'}
          </Button>
          <button
            type="button"
            onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }}
            className="w-full text-center text-sm text-leaf hover:underline"
          >
            {mode === 'login' ? 'New patient? Create an account' : 'Already have an account? Sign in'}
          </button>
        </form>
      </div>
    </div>
  );
}
