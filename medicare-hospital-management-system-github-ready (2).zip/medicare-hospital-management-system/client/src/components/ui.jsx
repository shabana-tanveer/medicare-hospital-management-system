export const inputCls =
  'w-full rounded-md border border-line bg-white px-3 py-2 text-sm focus:border-leaf focus:outline-none focus:ring-2 focus:ring-leaf/30';

export function Field({ label, children }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-ink/80">{label}</span>
      {children}
    </label>
  );
}

const variants = {
  primary: 'bg-leaf text-white hover:bg-leaf-dark',
  ghost: 'border border-line bg-white text-ink hover:bg-paper',
  danger: 'border border-rose-200 bg-white text-rose-700 hover:bg-rose-50'
};

export function Button({ variant = 'primary', className = '', ...props }) {
  return (
    <button
      className={`rounded-md px-3 py-2 text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50 disabled:opacity-50 ${variants[variant]} ${className}`}
      {...props}
    />
  );
}

const statusStyles = {
  Pending: 'bg-amber-100 text-amber-800',
  Confirmed: 'bg-sky-100 text-sky-800',
  Completed: 'bg-emerald-100 text-emerald-800',
  Cancelled: 'bg-stone-200 text-stone-700'
};

export function StatusBadge({ status }) {
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${statusStyles[status] || ''}`}>
      {status}
    </span>
  );
}

export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-ink/60">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function ErrorNote({ message }) {
  if (!message) return null;
  return (
    <p role="alert" className="mb-4 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-800">
      {message}
    </p>
  );
}

export function Empty({ children }) {
  return <p className="rounded-md border border-dashed border-line px-4 py-10 text-center text-sm text-ink/60">{children}</p>;
}

export const fmtDate = (d) =>
  new Date(`${d}T00:00:00`).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
