import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from './ui';

const NAV = [
  { to: '/', label: 'Overview', roles: ['admin', 'doctor', 'patient', 'receptionist'], end: true },
  { to: '/appointments', label: 'Appointments', roles: ['admin', 'doctor', 'patient', 'receptionist'] },
  { to: '/records', label: 'Medical records', roles: ['admin', 'doctor', 'patient'] },
  { to: '/people', label: 'People', roles: ['admin'] }
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const links = NAV.filter((n) => n.roles.includes(user.role));

  return (
    <div className="min-h-screen md:flex">
      <aside className="bg-ink text-white md:w-60 md:shrink-0">
        <div className="flex items-center justify-between px-5 py-4 md:block">
          <span className="text-lg font-semibold tracking-tight">MediCare</span>
          <span className="text-sm text-white/60 md:mt-1 md:block">{user.role}</span>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:pb-0">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                `whitespace-nowrap rounded-md px-3 py-2 text-sm transition-colors ${
                  isActive ? 'bg-white/15 font-medium text-white' : 'text-white/70 hover:bg-white/10'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-end gap-3 border-b border-line bg-white px-5 py-3">
          <span className="text-sm">{user.name}</span>
          <Button variant="ghost" onClick={logout}>Sign out</Button>
        </header>
        <main className="mx-auto w-full max-w-5xl flex-1 px-5 py-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
