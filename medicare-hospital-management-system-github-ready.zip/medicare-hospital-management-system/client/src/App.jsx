import React, { useState } from 'react';
import DashboardLayout from './components/DashboardLayout';
import AdminOverview from './pages/AdminOverview';
import AppointmentList from './pages/AppointmentList';

export default function App() {
  const [currentRole, setCurrentRole] = useState('admin');

  return (
    <DashboardLayout role={currentRole} setRole={setCurrentRole}>
      <AdminOverview />
      <AppointmentList />
    </DashboardLayout>
  );
}