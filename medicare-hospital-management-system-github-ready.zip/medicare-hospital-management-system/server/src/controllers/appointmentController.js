const Appointment = require('../models/Appointment');

// @desc Get all appointments
// @route GET /api/v1/appointments
exports.getAppointments = async (req, res, next) => {
  try {
    let query = {};
    if (req.user.role === 'patient') query.patient = req.user.id;
    if (req.user.role === 'doctor') query.doctor = req.user.id;

    const appointments = await Appointment.find(query)
      .populate('patient', 'name email phone bloodGroup')
      .populate('doctor', 'name specialization')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: appointments.length, data: appointments });
  } catch (err) {
    next(err);
  }
};

// @desc Create new appointment
// @route POST /api/v1/appointments
exports.createAppointment = async (req, res, next) => {
  try {
    const appointment = await Appointment.create(req.body);
    res.status(201).json({ success: true, data: appointment });
  } catch (err) {
    next(err);
  }
};